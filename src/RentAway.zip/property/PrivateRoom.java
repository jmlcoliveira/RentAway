package property;

/**
 * @author Guilherme Pocas 60236, Joao Oliveira 61052
 */
public interface PrivateRoom extends Property{

    void addAmenity(String amenity);
}
