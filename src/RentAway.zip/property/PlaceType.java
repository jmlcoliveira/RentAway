package property;

/**
 * @author Guilherme Pocas 60236, Joao Oliveira 61052
 */
public enum PlaceType {
    APARTMENT, HOUSE, CABIN
}
