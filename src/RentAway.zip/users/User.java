package users;

/**
 * @author Guilherme Pocas 60236, Joao Oliveira 61052
 */
public interface User{

    String getIdentifier();

    String getName();

    String getEmail();

    String getNationality();

}
